Here is a submachine gun, I have modeled and textured for a game project.

The concept was created by peter.k
piotrkupsc.weebly.com

Animated: No
Rigged: No
Lowpoly (game-ready): Yes
Geometry: Subdivision ready
Polygons: 4,755
Vertices: 7,913
Textures: Yes
Materials: Yes
UV Mapping: Yes
Unwrapped: UVs Non-overlapping

Demo-Video: https://www.youtube.com/watch?v=F-76xgLMQqs

Sketchfab 3D-Preview: https://sketchfab.com/models/nyWUiK6zmxBM5xpmP6mc7ZcXO76

Homepage : http://3dartdh.wordpress.com/
Contact me: https://3dartdh.wordpress.com/contact/

Sketchfab: https://sketchfab.com/dennish2010
YouTube: https://www.youtube.com/user/DennisH2010